const routes = {
  web: {
    dictionary: {
      textbox: 'dictionary-textbox',
      button: 'dictionary-button'
    },
    dashboard: '',
    login: 'login'
  },

  api: {

  }
}

export default routes;