import React from 'react'
import { createBrowserRouter } from 'react-router-dom';
import Layout from './views/layouts/Layout';
import { buildUrl, config } from './config';
import Authentication from './modules/authentication/index';

// TODO: Sử dụng react-router, tạo ra 2 trang: <AboutUs /> <==> /about
// TODO: <ContactUs /> <==> /contact

// TODO: Viết url: /product, trong đó sử dụng segment :name (/product/:name)
// TODO: /product/shoes%20ban%20gai ==> Tạo component để bắt shoes bạn gái
// và hiển thị lên màn hình
// <Outlet> / children

// Path: /dictionary/dictionary-textbox

const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        path: config.routes.web.dashboard,
        element: <p>Homepage</p>
      },
    ]
  },
  {
    path: buildUrl(config.routes.web.login),
    element: <Authentication />
  },
  {
    path: '/unauthorized',
    element: <p>Unauthorized</p>
  },
  {
    path: "*",
    element: <p>Not found</p>
  }
])

export default router