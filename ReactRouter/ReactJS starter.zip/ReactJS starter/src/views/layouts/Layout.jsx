import { Link, Outlet, useNavigate } from "react-router-dom"
import { config } from "../../config"

// useNavigate(): redirection
// useLocation(): persist some state


// TODO: Tạo ra layout bất kì, sau đó đặt nội dung vào trong đó - có sử dụng
// TODO: react-router

const Layout = () => { 
  return (
    <>
      <ul>
        <li><Link to={config.routes.web.dictionary.textbox}>Dictionary textbox modified</Link></li>
        <li><Link to={config.routes.web.dictionary.button}>Dictionary button modified</Link></li>
      </ul>

      <Outlet />
      </>
  )
}

export default Layout